#!/usr/bin/env python3
"""
Script de inferencia híbrido: ONNX Runtime + TensorRT
Usa ONNX inicialmente, luego TensorRT cuando esté disponible
"""

import sys
import json
import numpy as np
from PIL import Image
from pathlib import Path

# Clases
CLASS_NAMES = ['Black Sigatoka', 'Healthy', 'Panama', 'Yellow Sigatoka']

# Paths
MODEL_DIR = Path("/opt/banana-disease/models")
ONNX_PATH = MODEL_DIR / "best_model.onnx"
TRT_PATH = MODEL_DIR / "best_model_fp16.trt"


def preprocess_image(image_path, size=224):
    """Preprocesar imagen (mismo preprocesamiento que entrenamiento)"""
    img = Image.open(image_path).convert('RGB')
    img = img.resize((size, size), Image.BILINEAR)
    
    img_array = np.array(img).astype(np.float32) / 255.0
    
    mean = np.array([0.485, 0.456, 0.406])
    std = np.array([0.229, 0.224, 0.225])
    img_array = (img_array - mean) / std
    
    img_array = np.transpose(img_array, (2, 0, 1))
    img_array = np.expand_dims(img_array, axis=0)
    
    return img_array.astype(np.float32)


def infer_onnx(image_path):
    """Inferencia con ONNX Runtime"""
    import onnxruntime as ort
    
    session = ort.InferenceSession(str(ONNX_PATH))
    input_name = session.get_inputs()[0].name
    
    img_array = preprocess_image(image_path)
    outputs = session.run(None, {input_name: img_array})
    
    return outputs[0][0]


def infer_tensorrt(image_path):
    """Inferencia con TensorRT"""
    import tensorrt as trt
    import pycuda.driver as cuda
    import pycuda.autoinit
    
    TRT_LOGGER = trt.Logger(trt.Logger.WARNING)
    
    with open(str(TRT_PATH), 'rb') as f:
        runtime = trt.Runtime(TRT_LOGGER)
        engine = runtime.deserialize_cuda_engine(f.read())
    
    context = engine.create_execution_context()
    
    # Setup buffers
    bindings = []
    host_inputs = []
    host_outputs = []
    cuda_inputs = []
    cuda_outputs = []
    
    for binding in engine:
        shape = engine.get_binding_shape(binding)
        size = trt.volume(shape)
        dtype = trt.nptype(engine.get_binding_dtype(binding))
        
        host_mem = cuda.pagelocked_empty(size, dtype)
        cuda_mem = cuda.mem_alloc(host_mem.nbytes)
        
        bindings.append(int(cuda_mem))
        
        if engine.binding_is_input(binding):
            host_inputs.append(host_mem)
            cuda_inputs.append(cuda_mem)
        else:
            output_shape = shape
            host_outputs.append(host_mem)
            cuda_outputs.append(cuda_mem)
    
    # Preprocesar
    input_data = preprocess_image(image_path)
    
    # Inferencia
    np.copyto(host_inputs[0], input_data.ravel())
    cuda.memcpy_htod_async(cuda_inputs[0], host_inputs[0])
    context.execute_v2(bindings=bindings)
    cuda.memcpy_dtoh_async(host_outputs[0], cuda_outputs[0])
    cuda.Context.synchronize()
    
    output = host_outputs[0].reshape(output_shape)
    return output[0]


def predict(image_path):
    """Predicción (usa TensorRT si existe, sino ONNX)"""
    
    # Decidir qué usar
    use_tensorrt = TRT_PATH.exists()
    
    # Inferencia
    if use_tensorrt:
        logits = infer_tensorrt(image_path)
    else:
        logits = infer_onnx(image_path)
    
    # Softmax
    exp_logits = np.exp(logits - np.max(logits))
    probabilities = exp_logits / np.sum(exp_logits)
    
    # Predicción
    pred_idx = np.argmax(probabilities)
    pred_class = CLASS_NAMES[pred_idx]
    confidence = probabilities[pred_idx] * 100
    
    return {
        "success": True,
        "prediction": {
            "disease": pred_class,
            "confidence": float(confidence),
            "is_certain": confidence >= 75
        },
        "probabilities": {
            CLASS_NAMES[i]: float(probabilities[i] * 100)
            for i in range(len(CLASS_NAMES))
        },
        "engine": "tensorrt" if use_tensorrt else "onnx"
    }


if __name__ == '__main__':
    if len(sys.argv) < 2:
        print(json.dumps({
            "success": False,
            "error": "No image path provided"
        }))
        sys.exit(1)
    
    try:
        result = predict(sys.argv[1])
        print(json.dumps(result, indent=2))
    except Exception as e:
        print(json.dumps({
            "success": False,
            "error": str(e)
        }))
        sys.exit(1)
